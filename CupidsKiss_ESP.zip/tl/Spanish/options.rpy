﻿# TODO: Translation updated at 2026-10-12 16:24

translate Spanish strings:

    # game/options.rpy:15
    old "Cupids Kiss"
    new "Cupids Kiss"

