﻿# TODO: Translation updated at 2026-10-12 11:06

translate Spanish strings:

    # game/screens.rpy:320
    old "Start"
    new "Comenzar"

    # game/screens.rpy:324
    old "History"
    new "Historial"

    # game/screens.rpy:326
    old "Save"
    new "Guardar"

    # game/screens.rpy:328
    old "Load"
    new "Cargar"

    # game/screens.rpy:330
    old "Preferences"
    new "Preferencias"

    # game/screens.rpy:334
    old "End Replay"
    new "Terminar repetición"

    # game/screens.rpy:338
    old "Main Menu"
    new "Menú principal"

    # game/screens.rpy:340
    old "About"
    new "Acerca de"

    # game/screens.rpy:345
    old "Help"
    new "Ayuda"

    # game/screens.rpy:351
    old "Quit"
    new "Salir"

    # game/screens.rpy:549
    old "Return"
    new "Volver"

    # game/screens.rpy:633
    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:639
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:673
    old "Page {}"
    new "Página {}"

    # game/screens.rpy:673
    old "Automatic saves"
    new "Guardados automáticos"

    # game/screens.rpy:673
    old "Quick saves"
    new "Guardados rápidos"

    # game/screens.rpy:715
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %d de %B de %Y, %H:%M"

    # game/screens.rpy:715
    old "empty slot"
    new "espacio vacío"

    # game/screens.rpy:735
    old "<"
    new "<"

    # game/screens.rpy:738
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:741
    old "{#quick_page}Q"
    new "{#quick_page}R"

    # game/screens.rpy:747
    old ">"
    new ">"

    # game/screens.rpy:751
    old "Upload Sync"
    new "Subir sincronización"

    # game/screens.rpy:755
    old "Download Sync"
    new "Descargar sincronización"

    # game/screens.rpy:847
    old "Music"
    new "Música"

    # game/screens.rpy:859
    old "Sound"
    new "Sonido"

    # game/screens.rpy:867
    old "Test"
    new "Probar"

    # game/screens.rpy:875
    old "Voice"
    new "Voz"

    # game/screens.rpy:893
    old "Text Speed"
    new "Velocidad del texto"

    # game/screens.rpy:1036
    old "The dialogue history is empty."
    new "El historial de diálogo está vacío."

    # game/screens.rpy:1104
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:1105
    old "Mouse"
    new "Mouse"

    # game/screens.rpy:1108
    old "Gamepad"
    new "Mando"

    # game/screens.rpy:1121
    old "Enter"
    new "Intro"

    # game/screens.rpy:1122
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:1125
    old "Space"
    new "Espacio"

    # game/screens.rpy:1126
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # game/screens.rpy:1129
    old "Arrow Keys"
    new "Teclas de flecha"

    # game/screens.rpy:1130
    old "Navigate the interface."
    new "Navega por la interfaz."

    # game/screens.rpy:1133
    old "Escape"
    new "Esc"

    # game/screens.rpy:1134
    old "Accesses the game menu."
    new "Accede al menú del juego."

    # game/screens.rpy:1137
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1138
    old "Skips dialogue while held down."
    new "Salta el diálogo mientras se mantiene pulsada."

    # game/screens.rpy:1141
    old "Tab"
    new "Tab"

    # game/screens.rpy:1142
    old "Toggles dialogue skipping."
    new "Activa o desactiva el salto de diálogo."

    # game/screens.rpy:1145
    old "Page Up"
    new "Re Pág"

    # game/screens.rpy:1146
    old "Rolls back to earlier dialogue."
    new "Retrocede a un diálogo anterior."

    # game/screens.rpy:1149
    old "Page Down"
    new "Av Pág"

    # game/screens.rpy:1150
    old "Rolls forward to later dialogue."
    new "Avanza a un diálogo posterior."

    # game/screens.rpy:1154
    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    # game/screens.rpy:1158
    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    # game/screens.rpy:1162
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa o desactiva la {a=https://www.renpy.org/l/voicing}autovoz{/a} de asistencia."

    # game/screens.rpy:1166
    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:1172
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:1176
    old "Middle Click"
    new "Clic central"

    # game/screens.rpy:1180
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:1184
    old "Mouse Wheel Up"
    new "Rueda del mouse hacia arriba"

    # game/screens.rpy:1188
    old "Mouse Wheel Down"
    new "Rueda del mouse hacia abajo"

    # game/screens.rpy:1195
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nA/Botón inferior"

    # game/screens.rpy:1199
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nBotón superior izquierdo"

    # game/screens.rpy:1203
    old "Right Shoulder"
    new "Botón superior derecho"

    # game/screens.rpy:1207
    old "D-Pad, Sticks"
    new "Cruceta, palancas"

    # game/screens.rpy:1211
    old "Start, Guide, B/Right Button"
    new "Start, Guía, B/Botón derecho"

    # game/screens.rpy:1215
    old "Y/Top Button"
    new "Y/Botón superior"

    # game/screens.rpy:1218
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:1342
    old "Skipping"
    new "Saltando"

