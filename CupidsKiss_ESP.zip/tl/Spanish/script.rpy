﻿# TODO: Translation updated at 2026-10-12 11:06

# game/script.rpy:90
translate Spanish start_750fa831:

    # voice "youreallycanttake"
    # v "You really can’t take a hint, can you?"
    voice "youreallycanttake"
    v "De verdad no captas las indirectas, ¿eh?"

# game/script.rpy:93
translate Spanish start_92ec929f:

    # "<I look up from the coffee stain I’m dabbing.>"
    "<Levanto la vista de la mancha de café que estoy secando con toquecitos.>"

# game/script.rpy:101
translate Spanish start_85df528d:

    # voice "youheardme"
    # v neutral_talk "You heard me."
    voice "youheardme"
    v neutral_talk "Me oíste."

# game/script.rpy:121
translate Spanish start_notblind_2b9b1e01:

    # voice "guessyouarentblind"
    # v amused_talk "Guess you {i}aren’t{/i} blind."
    voice "guessyouarentblind"
    v amused_talk "Así que {i}sí{/i} ves bien."

# game/script.rpy:125
translate Spanish start_notblind_8f70aa76:

    # voice "gladwecanfinally"
    # v sarcastic_talk "Glad we can finally rule that out."
    voice "gladwecanfinally"
    v sarcastic_talk "Me alegra poder descartarlo por fin."

# game/script.rpy:136
translate Spanish start_thefourthtime_ee23bb60:

    # voice "thatsthefourthtime"
    # v neutral_talk2 "That’s the fourth time this week that an unnaturally beautiful stranger has dumped their coffee on you."
    voice "thatsthefourthtime"
    v neutral_talk2 "Es la cuarta vez esta semana que un desconocido de una belleza sobrenatural te tira el café encima."

# game/script.rpy:138
translate Spanish start_thefourthtime_736946d6:

    # voice "butdidyoubother"
    # v amused_talk "But did you bother looking at their face?"
    voice "butdidyoubother"
    v amused_talk "¿Pero te molestaste en mirarle la cara?"

# game/script.rpy:140
translate Spanish start_thefourthtime_4709291c:

    # voice "flutteringyourlashes"
    # v sarcastic_talk "Fluttering your lashes?"
    voice "flutteringyourlashes"
    v sarcastic_talk "¿Aleteando las pestañas?"

# game/script.rpy:142
translate Spanish start_thefourthtime_a4bd7e65:

    # voice "makingsmalltalk"
    # v serious_talk "Making small talk?"
    voice "makingsmalltalk"
    v serious_talk "¿Charlando de cosas triviales?"

# game/script.rpy:144
translate Spanish start_thefourthtime_059ef283:

    # voice "itslikeyouretrying"
    # v angry_talk "It’s like you’re {i}trying{/i} to make my life harder."
    voice "itslikeyouretrying"
    v angry_talk "Es como si {i}intentaras{/i} complicarme la vida."

# game/script.rpy:152
translate Spanish start_thefourthtime_1c4e3fe1:

    # voice "darlingimgoingto"
    # v rueful_talk "Darling, I'm going to need you to accept a lot of bizarre things at face value."
    voice "darlingimgoingto"
    v rueful_talk "Cariño, voy a necesitar que aceptes muchas cosas extrañas tal como vienen."

# game/script.rpy:154
translate Spanish start_thefourthtime_9d17bf87:

    # voice "ifyouregettingstuck"
    # v neutral_talk "If you're getting stuck on wings, we're going to have a problem."
    voice "ifyouregettingstuck"
    v neutral_talk "Si te atascas con lo de las alas, vamos a tener un problema."

# game/script.rpy:162
translate Spanish start_thefourthtime_438759a0:

    # voice "thatsmylinedear"
    # v serious_talk "That's my line, dear."
    voice "thatsmylinedear"
    v serious_talk "Esa es mi frase, cariño."

# game/script.rpy:167
translate Spanish start_imacupid_ab1a55d8:

    # voice "imnotsurehow"
    # v worried_talk "I'm not sure how long we have, so {i}try{/i} to keep up."
    voice "imnotsurehow"
    v worried_talk "No sé cuánto tiempo tenemos, así que {i}intenta{/i} seguirme el ritmo."

# game/script.rpy:169
translate Spanish start_imacupid_108b08b3:

    # voice "mynameisvirgil"
    # v sarcastic_talk "My name is Virgil, I'm a Cupid and I'm at your service. Literally."
    voice "mynameisvirgil"
    v sarcastic_talk "Me llamo Virgil, soy un Cupido y estoy a tu servicio. Literalmente."

# game/script.rpy:171
translate Spanish start_imacupid_04b916b7:

    # voice "fiftyyearsofflawless"
    # v amused_talk "Fifty years of flawless work, rave reviews, not a single Loveless on my watch."
    voice "fiftyyearsofflawless"
    v amused_talk "Cincuenta años de trabajo impecable, reseñas excelentes y ni un solo 'Sinamor' bajo mi supervisión."

# game/script.rpy:173
translate Spanish start_imacupid_8e84d0e0:

    # voice "andthenyou"
    # v angry_talk "And then... {i}you{/i}."
    voice "andthenyou"
    v angry_talk "Y entonces... {i}tú{/i}."

# game/script.rpy:180
translate Spanish start_imacupid_f47e5ed8:

    # "<His finger gently taps me on the forehead.>"
    "<Su dedo me da un toquecito suave en la frente.>"

# game/script.rpy:187
translate Spanish start_imacupid_6080c63f:

    # voice "ipullallthe"
    # v angry_talk "I pull all the stops: trapped in lifts, only one bed, reuniting with childhood crushes... the works."
    voice "ipullallthe"
    v angry_talk "Lo he intentado todo: atrapados en ascensores, una sola cama, reencuentros con amores de la infancia... el paquete completo."

# game/script.rpy:189
translate Spanish start_imacupid_ad987364:

    # voice "atthispointyour"
    # v sceptical_talk "At this point, your entire life is like an obnoxious rom-com."
    voice "atthispointyour"
    v sceptical_talk "A estas alturas, toda tu vida parece una comedia romántica insoportable."

# game/script.rpy:191
translate Spanish start_imacupid_ccf05055:

    # voice "butitslikeyou"
    # v angry_talk "But it's like you don't... notice. Or {i}care{/i}."
    voice "butitslikeyou"
    v angry_talk "Pero es como si no... te dieras cuenta. O no te {i}importara{/i}."

# game/script.rpy:193
translate Spanish start_imacupid_6a970ab0:

    # voice "whateverthecaseim"
    # v serious_talk "Whatever the case, I'm at my wits end."
    voice "whateverthecaseim"
    v serious_talk "Sea como sea, ya no sé qué más hacer."

# game/script.rpy:195
translate Spanish start_imacupid_940e6d52:

    # voice "ifigureditseither"
    # v sarcastic_talk "I figured it's either {i}this{/i} or admitting to HQ that I failed."
    voice "ifigureditseither"
    v sarcastic_talk "Pensé que era o {i}esto{/i} o admitir ante la central que fracasé."

# game/script.rpy:197
translate Spanish start_imacupid_cc7b875a:

    # voice "andidratherbe"
    # v muhaha_talk "And I'd rather be pulverised for rule breaking than give that condescending prick Valentine the satisfaction."
    voice "andidratherbe"
    v muhaha_talk "Y prefiero que me pulvericen por romper las reglas antes que darle esa satisfacción al cretino condescendiente de Valentine."

# game/script.rpy:199
translate Spanish start_imacupid_bb2918d4:

    # voice "nowtellmewhat"
    # v neutral_talk "Now tell me: what are we going to do about this little snafu?"
    voice "nowtellmewhat"
    v neutral_talk "Ahora dime: ¿qué vamos a hacer con este pequeño enredo?"

# game/script.rpy:205
translate Spanish start_imacupid_49278126:

    # voice "handsomerandos"
    # v amused_talk "{i}Handsome{/i} randos."
    voice "handsomerandos"
    v amused_talk "Desconocidos {i}guapos{/i}."

# game/script.rpy:210
translate Spanish start_imacupid_7f5c0e44:

    # voice "ivettedthemfirst"
    # v sarcastic_talk "I vetted them first. They weren't creeps."
    voice "ivettedthemfirst"
    v sarcastic_talk "Los investigué antes. No eran unos raros."

# game/script.rpy:217
translate Spanish start_imacupid_8c41429e:

    # voice "ohicansee"
    # v shocked_talk "Oh. I can see now how that might be upsetting."
    voice "ohicansee"
    v shocked_talk "Oh. Ya veo cómo eso puede resultar molesto."

# game/script.rpy:219
translate Spanish start_imacupid_0e32b7c1:

    # voice "seethisiswhy"
    # v sarcastic_talk "See, {i}this{/i} is why this little chat is long overdue."
    voice "seethisiswhy"
    v sarcastic_talk "¿Ves? Por {i}esto{/i} esta charlita estaba más que pendiente."

# game/script.rpy:227
translate Spanish start_imacupid_755d780b:

    # voice "isntthatobvious"
    # v sarcastic_talk "Isn't that obvious?"
    voice "isntthatobvious"
    v sarcastic_talk "¿No es obvio?"

# game/script.rpy:232
translate Spanish start_imacupid_c1d7ffe3:

    # voice "ohthanksiappreciate"
    # v shocked_talk "Oh. Thanks, I appreciate that."
    voice "ohthanksiappreciate"
    v shocked_talk "Oh. Gracias, lo aprecio."

# game/script.rpy:234
translate Spanish start_imacupid_9f13c5e9:

    # voice "ihadafeeling"
    # v rueful_talk "I had a feeling you'd be less... understanding."
    voice "ihadafeeling"
    v rueful_talk "Tenía la sensación de que te lo tomarías con menos... comprensión."

# game/script.rpy:239
translate Spanish start_iwantyoutofallinlove_74bb963a:

    # voice "whatineedis"
    # v neutral_talk "What I {i}need{/i} is for you to fall in love already."
    voice "whatineedis"
    v neutral_talk "Lo que {i}necesito{/i} es que te enamores de una vez."

# game/script.rpy:246
translate Spanish start_iwantyoutofallinlove_7d23eb68:

    # voice "hahayeshilarious"
    # v sarcastic_talk "Haha, yes, hilarious."
    voice "hahayeshilarious"
    v sarcastic_talk "Ja, ja, sí, graciosísimo."

# game/script.rpy:248
translate Spanish start_iwantyoutofallinlove_61efa3d8:

    # voice "imnotplayinghere"
    # v serious_talk "I’m not playing here."
    voice "imnotplayinghere"
    v serious_talk "No estoy jugando."

# game/script.rpy:255
translate Spanish start_iwantyoutofallinlove_07b96738:

    # voice "itsliterallymyjob"
    # v sceptical_talk "It’s {i}literally{/i} my job, ergo it doesn’t count as play."
    voice "itsliterallymyjob"
    v sceptical_talk "Es {i}literalmente{/i} mi trabajo, ergo no cuenta como jugar."

# game/script.rpy:261
translate Spanish start_iwantyoutofallinlove_4561fa04:

    # voice "ohshuddup"
    # v rueful_talk "Oh, shuddup."
    voice "ohshuddup"
    v rueful_talk "Ay, cállate."

# game/script.rpy:268
translate Spanish start_iwantyoutofallinlove_72e227bd:

    # voice "asaheartattack"
    # v neutral_talk2 "As a heart attack, my dear."
    voice "asaheartattack"
    v neutral_talk2 "Más en serio que un infarto, cariño."

# game/script.rpy:270
translate Spanish start_iwantyoutofallinlove_04e15522:

    # voice "idealinlove"
    # v amused_talk "I deal in love and you’re one stingy customer."
    voice "idealinlove"
    v amused_talk "Yo vendo amor y tú no me compras ni una pizca."

# game/script.rpy:276
translate Spanish start_iwantyoutofallinlove_9cd5bdb4:

    # voice "thenwhyhaventyou"
    # v sarcastic_talk "Then why haven’t you fallen for anyone?!"
    voice "thenwhyhaventyou"
    v sarcastic_talk "¡¿Entonces por qué no te has enamorado de nadie?!"

# game/script.rpy:279
translate Spanish start_iwantyoutofallinlove_f95f49b0:

    # voice "lookicantmove"
    # v serious_talk "Look, I can't move on to my next assignment until your stomach goes all aflutter."
    voice "lookicantmove"
    v serious_talk "Mira, no puedo pasar a mi siguiente misión hasta que sientas mariposas en el estómago."

# game/script.rpy:281
translate Spanish start_iwantyoutofallinlove_5fffc341:

    # voice "itsnotjustfor"
    # v amused_talk "It's not just for me, I'm sure you're done with the tropey bullshit yourself."
    voice "itsnotjustfor"
    v amused_talk "No es solo por mí; seguro que a ti también te tiene hasta la coronilla toda esta mierda de clichés."

# game/script.rpy:283
translate Spanish start_iwantyoutofallinlove_6b4c64c7:

    # voice "iambeggingyou"
    # v worried_talk "I am {i}begging{/i} you. It’s been three months since I was assigned to you–"
    voice "iambeggingyou"
    v worried_talk "Te lo estoy {i}suplicando{/i}. Han pasado tres meses desde que me asignaron a ti–"

# game/script.rpy:289
translate Spanish start_iwantyoutofallinlove_c26a1a66:

    # voice "imgladyoufind"
    # v amused_talk "I’m glad you find this funny."
    voice "imgladyoufind"
    v amused_talk "Qué bueno que te parezca gracioso."

# game/script.rpy:298
translate Spanish start_iwantyoutofallinlove_f4ea50c9:

    # voice "soyoudidnotice"
    # v muhaha blush "So you did notice."
    voice "soyoudidnotice"
    v muhaha blush "Así que sí te diste cuenta."

# game/script.rpy:310
translate Spanish start_iwantyoutofallinlove_eb8bf22c:

    # "<There's a pause, his face conflicted.>"
    "<Hay una pausa; su rostro refleja un conflicto.>"

# game/script.rpy:313
translate Spanish start_iwantyoutofallinlove_619908c4:

    # voice "obviouslynot"
    # v serious "Obviously not."
    voice "obviouslynot"
    v serious "Obviamente no."

# game/script.rpy:316
translate Spanish start_iwantyoutofallinlove_c6a7702c:

    # voice "usuallyitsinand"        
    # v serious_talk "Usually it's in and out, one or two tropes max."
    voice "usuallyitsinand"        
    v serious_talk "Normalmente es entrar y salir: uno o dos clichés como máximo."

# game/script.rpy:318
translate Spanish start_iwantyoutofallinlove_10e5a76b:

    # voice "butwithyounothing"
    # v worried_talk blush "But with you... nothing was working, so I doubled down."
    voice "butwithyounothing"
    v worried_talk blush "Pero contigo... nada funcionaba, así que redoblé la apuesta."

# game/script.rpy:323
translate Spanish start_iwantyoutofallinlove_c5c2ed8c:

    # voice "ishouldprobablyhave"
    # v serious_talk "I should probably have stopped, but I didn't want to admit I was struggling."
    voice "ishouldprobablyhave"
    v serious_talk "Seguramente debí parar, pero no quería admitir que me estaba costando."

# game/script.rpy:325
translate Spanish start_iwantyoutofallinlove_9c481215:

    # voice "andyougotcaught"
    # v rueful_talk "And you got caught in the middle."
    voice "andyougotcaught"
    v rueful_talk "Y tú quedaste en medio de todo."

# game/script.rpy:331
translate Spanish start_iwantyoutofallinlove_319264ba:

    # voice "iamsorry"
    # v serious_talk "I {i}am{/i} sorry."
    voice "iamsorry"
    v serious_talk "De verdad {i}lo siento{/i}."

# game/script.rpy:333
translate Spanish start_iwantyoutofallinlove_260d8090:

    # voice "iknowitsbeen"
    # v worried_talk "I know it's been a {i}lot{/i}."
    voice "iknowitsbeen"
    v worried_talk "Sé que ha sido {i}mucho{/i}."

# game/script.rpy:338
translate Spanish start_iwantyoutofallinlove_61b8a22b:

    # voice "ibegyourpardon"
    # v angry_talk "I beg your pardon, I’m {i}excellent{/i} at my job."
    voice "ibegyourpardon"
    v angry_talk "Perdona, soy {i}excelente{/i} en mi trabajo."

# game/script.rpy:340
translate Spanish start_iwantyoutofallinlove_605814d4:

    # voice "youretheonewhos"
    # v serious_talk "You’re the one who’s... defective."
    voice "youretheonewhos"
    v serious_talk "Quien tiene un... defecto de fábrica eres tú."

# game/script.rpy:342
translate Spanish start_iwantyoutofallinlove_aea3a9a7:

    # voice "probably"
    # v worried_talk "Probably."
    voice "probably"
    v worried_talk "Probablemente."

# game/script.rpy:358
translate Spanish start_iwantyoutofallinlove_861e6294:

    # voice "maybeiam"
    # v worried_talk "Maybe I am."
    voice "maybeiam"
    v worried_talk "Quizá lo sea."

# game/script.rpy:363
translate Spanish start_iwantyoutofallinlove_5663afd2:

    # voice "iknowyoudthink"
    # v rueful_talk "I know. You'd think after fifty years it'd get easier, but it hasn't."
    voice "iknowyoudthink"
    v rueful_talk "Lo sé. Uno pensaría que tras cincuenta años sería más fácil, pero no."

# game/script.rpy:370
translate Spanish start_iwantyoutofallinlove_f327fc78:

    # voice "imgladtooyou"
    # v rueful_talk "I'm glad too. You make it palatable."
    voice "imgladtooyou"
    v rueful_talk "Yo también me alegro. Tú lo haces más llevadero."

# game/script.rpy:375
translate Spanish start_iwantyoutofallinlove_95d1d07e:

    # voice "yeahlimboisntbig"
    # v rueful_talk "Yeahhhh, Limbo isn't big on mental health."
    voice "yeahlimboisntbig"
    v rueful_talk "Sííí, al Limbo no le va mucho eso de la salud mental."

# game/script.rpy:377
translate Spanish start_iwantyoutofallinlove_898cec29:

    # voice "ifwegotover"
    # v sarcastic_talk "If we got over our problems, we'd just move on and they'd lose their free labour."
    voice "ifwegotover"
    v sarcastic_talk "Si superáramos nuestros problemas, seguiríamos adelante y perderían su mano de obra gratis."

# game/script.rpy:379
translate Spanish start_iwantyoutofallinlove_8db25734:

    # voice "canthavethatcan"
    # v rueful_talk "Can't have that, can we?"
    voice "canthavethatcan"
    v rueful_talk "No podemos permitirlo, ¿verdad?"

# game/script.rpy:388
translate Spanish start_iwantyoutofallinlove_570bd720:

    # voice "alifetimeago"
    # v rueful_talk "A lifetime ago."
    voice "alifetimeago"
    v rueful_talk "Hace toda una vida."

# game/script.rpy:390
translate Spanish start_iwantyoutofallinlove_9e9ec722:

    # voice "igotluckymost"
    # v serious_talk "I got lucky. Most of the people there wander aimlessly for all eternity."
    voice "igotluckymost"
    v serious_talk "Tuve suerte. La mayoría de la gente de allí vaga sin rumbo por toda la eternidad."

# game/script.rpy:395
translate Spanish start_iwantyoutofallinlove_372c87d7:

    # voice "itsmyjobto"
    # v amused_talk "It's my job to ensure you never get the chance to find out."
    voice "itsmyjobto"
    v amused_talk "Mi trabajo es asegurarme de que nunca tengas la oportunidad de averiguarlo."

# game/script.rpy:399
translate Spanish start_iwantyoutofallinlove_eb371166:

    # voice "definitelypaysbetter"
    # v amused_talk "Definitely pays better."
    voice "definitelypaysbetter"
    v amused_talk "Desde luego, paga mejor."

# game/script.rpy:403
translate Spanish start_iwantyoutofallinlove_62e90ecb:

    # voice "regardlesswerestucktogether"
    # v sarcastic_talk "Regardless, we’re stuck together until we can get your dead heart beating again."
    voice "regardlesswerestucktogether"
    v sarcastic_talk "Sea como sea, estamos atados hasta que logremos que tu corazón muerto vuelva a latir."

# game/script.rpy:405
translate Spanish start_iwantyoutofallinlove_590f60b5:

    # voice "andimsureyou"
    # v rueful_talk "And I'm sure you share my desire to get unstuck as soon as possible."
    voice "andimsureyou"
    v rueful_talk "Y seguro que compartes mi deseo de desatarnos cuanto antes."

# game/script.rpy:429
translate Spanish start_beatingheart_079d7cc5:

    # voice "atthispointid"
    # v sceptical_talk "At this point I'd settle for a dumb crush."
    voice "atthispointid"
    v sceptical_talk "A estas alturas me conformaría con un simple enamoramiento tonto."

# game/script.rpy:431
translate Spanish start_beatingheart_d7e18939:

    # voice "hellanenthusiasticsnog"
    # v sarcastic_talk "Hell, an enthusiastic snog."
    voice "hellanenthusiasticsnog"
    v sarcastic_talk "Demonios, hasta con un beso apasionado."

# game/script.rpy:433
translate Spanish start_beatingheart_3acd8eb3:

    # voice "itshouldbefalling"
    # v muhaha_talk "It {i}should{/i} be falling in love, but the rules are positively medieval and I'm past caring."
    voice "itshouldbefalling"
    v muhaha_talk "{i}Debería{/i} ser enamorarte, pero las reglas son francamente medievales y ya me da igual."

# game/script.rpy:435
translate Spanish start_beatingheart_9365cbf6:

    # voice "justpickanyoneyoure"
    # v amused_talk "Just pick anyone you’re vaguely attracted to."
    voice "justpickanyoneyoure"
    v amused_talk "Elige a cualquiera que te atraiga aunque sea un poco."

# game/script.rpy:443
translate Spanish start_kisschoice_3fb7ddff:

    # voice "hilarious"
    # v sarcastic_talk "{i}Hilarious{/i}."
    voice "hilarious"
    v sarcastic_talk "{i}Graciosísimo{/i}."

# game/script.rpy:449
translate Spanish start_kisschoice_2acae228:

    # voice "wellthenidbest"
    # v amused_talk "Well, then I'd best get comfortable."
    voice "wellthenidbest"
    v amused_talk "Bueno, entonces será mejor que me ponga cómodo."

# game/script.rpy:451
translate Spanish start_kisschoice_f93ec68f:

    # voice "whatstheaveragehuman"
    # v sarcastic_talk "What's the average human lifespan nowadays?"
    voice "whatstheaveragehuman"
    v sarcastic_talk "¿Cuál es la esperanza de vida humana promedio hoy en día?"

# game/script.rpy:453
translate Spanish start_kisschoice_90990f0c:

    # voice "100years"
    # v muhaha_talk "100 years?"
    voice "100years"
    v muhaha_talk "¿100 años?"

# game/script.rpy:455
translate Spanish start_kisschoice_7f763ea3:

    # voice "shouldgobyin"
    # v sarcastic_talk "Should go by in a jiffy."
    voice "shouldgobyin"
    v sarcastic_talk "Pasará en un suspiro."

# game/script.rpy:466
translate Spanish start_cupidkiss_269a516a:

    # voice "meumimnot"
    # v shocked_talk blush "Me?! Uhm, I'm not sure I qualify–"
    voice "meumimnot"
    v shocked_talk blush "¡¿Yo?! Eh, no estoy seguro de calificar–"

# game/script.rpy:474
translate Spanish start_cupidkiss_4d64cc35:

    # voice "yesbeforeidied"
    # v worried_talk "Yes, {i}before{/i} I died."
    voice "yesbeforeidied"
    v worried_talk "Sí, {i}antes{/i} de morir."

# game/script.rpy:477
translate Spanish start_cupidkiss_5fc51fe3:

    # voice "darlingtheresplentyof"
    # v rueful_talk "Darling, there's plenty of viable, {i}living{/i} candidates who would be thrilled to kiss you–"
    voice "darlingtheresplentyof"
    v rueful_talk "Cariño, hay muchísimos candidatos viables y {i}vivos{/i} a los que les encantaría besarte–"

# game/script.rpy:485
translate Spanish start_cupidkiss_ff23295d:

    # voice "ofcourseiwould"
    # v worried_talk "Of course I would!"
    voice "ofcourseiwould"
    v worried_talk "¡Claro que sí!"

# game/script.rpy:487
translate Spanish start_cupidkiss_d32006d3:

    # voice "ijustdontthink"
    # v rueful_talk "I just don't think you’re clear on the possibilities."
    voice "ijustdontthink"
    v rueful_talk "Es solo que no creo que tengas claras las posibilidades."

# game/script.rpy:489
translate Spanish start_cupidkiss_400092ff:

    # voice "justpickaperson"
    # v worried_talk "Just pick a person, {i}any{/i} person and I'll make it happen."
    voice "justpickaperson"
    v worried_talk "Elige a una persona, {i}cualquiera{/i}, y yo lo haré realidad."

# game/script.rpy:496
translate Spanish start_cupidkiss_0063b1da:

    # voice "ithoughtyousaid"
    # v rueful_talk "I thought you said you're discerning."
    voice "ithoughtyousaid"
    v rueful_talk "Creía que habías dicho que eras exigente."

# game/script.rpy:503
translate Spanish start_cupidkiss_acb80eef:

    # voice "7.9billionpeopleim"
    # v serious_talk "7.9 billion people. I'm offering you {i}any{/i} person in the world on a silver platter–"
    voice "7.9billionpeopleim"
    v serious_talk "7.900 millones de personas. Te ofrezco a {i}cualquiera{/i} del mundo en bandeja de plata–"

# game/script.rpy:509
translate Spanish start_cupidkiss_23b413d0:

    # voice "amnot"
    # v angry_talk "Am not!"
    voice "amnot"
    v angry_talk "¡Que no!"

# game/script.rpy:511
translate Spanish start_cupidkiss_71d76901:

    # voice "well"
    # v worried_talk "Well."
    voice "well"
    v worried_talk "Bueno."

# game/script.rpy:513
translate Spanish start_cupidkiss_f7193746:

    # voice "maybe"
    # v rueful_talk "{i}Maybe{/i}."
    voice "maybe"
    v rueful_talk "{i}Quizá{/i}."

# game/script.rpy:525
translate Spanish start_cupidkiss_9f6c65ef:

    # "He swallows and my heart thumps wildly in my chest."
    "Traga saliva y mi corazón late desbocado en mi pecho."

# game/script.rpy:527
translate Spanish start_cupidkiss_fdb64195:

    # voice "whyme"
    # v worried_talk "Why {i}me{/i}?"
    voice "whyme"
    v worried_talk "¿Por qué {i}yo{/i}?"

# game/script.rpy:536
translate Spanish start_cupidkiss_c7dc8ee8:

    # voice "isayalot"
    # v rueful_talk "I say a {i}lot{/i} of things."
    voice "isayalot"
    v rueful_talk "Digo {i}muchas{/i} cosas."

# game/script.rpy:555
translate Spanish start_cupidkiss_a90b405c:

    # voice "but"
    # v worried_talk "But–"
    voice "but"
    v worried_talk "Pero–"

# game/script.rpy:563
translate Spanish start_cupidkiss_79e6b994:

    # voice "ohiwantto"
    # v worried_talk "Oh, I want to."
    voice "ohiwantto"
    v worried_talk "Oh, claro que quiero."

# game/script.rpy:565
translate Spanish start_cupidkiss_bd822aba:

    # voice "ijusthinkits"
    # v rueful_talk "I just think it's a terrible idea."
    voice "ijusthinkits"
    v rueful_talk "Es solo que me parece una idea pésima."

# game/script.rpy:574
translate Spanish start_cupidkiss_48ee1489:

    # voice "imafewcenturies"
    # v amused_talk "I'm a few centuries out of practice."
    voice "imafewcenturies"
    v amused_talk "Llevo unos cuantos siglos sin practicar."

# game/script.rpy:577
translate Spanish start_cupidkiss_ad33e2f6:

    # voice "yourelovelytruly"
    # v rueful_talk "You're... lovely. {i}Truly{/i}."
    voice "yourelovelytruly"
    v rueful_talk "Eres... un encanto. {i}De verdad{/i}."

# game/script.rpy:589
translate Spanish start_cupidkiss_b562f6bd:

    # "I gently comb my fingers through the hair at the nape of his neck."
    "Paso suavemente los dedos por el cabello de su nuca."

# game/script.rpy:594
translate Spanish start_cupidkiss_74f91b20:

    # "He leans into me, putting his forehead to mine."
    "Se inclina hacia mí y apoya su frente en la mía."

# game/script.rpy:598
translate Spanish start_cupidkiss_392f03a3:

    # "I wonder if I'll miss it, the presence I never even knew was there."
    "Me pregunto si lo echaré de menos, esa presencia que ni siquiera sabía que estaba ahí."

# game/script.rpy:606
translate Spanish start_cupidkiss_f1896b20:

    # "The smile I've only just seen, but seems somehow... familiar."
    "La sonrisa que acabo de ver, pero que de algún modo... me resulta familiar."

# game/script.rpy:611
translate Spanish start_cupidkiss_76319bcd:

    # "It feels {i}right{/i}."
    "Se siente {i}bien{/i}."

# game/script.rpy:626
translate Spanish start_cupidkiss_37ba86f2:

    # n "A lifetime later..."
    n "Toda una vida después..."

# game/script.rpy:634
translate Spanish start_cupidkiss_0dfd4660:

    # e "The cruellest of fates."
    e "El más cruel de los destinos."

# game/script.rpy:635
translate Spanish start_cupidkiss_5431a2bd:

    # e "The most bruised of souls."
    e "La más magullada de las almas."

# game/script.rpy:636
translate Spanish start_cupidkiss_ca5abf1d:

    # e "Falling in love for just a second and carrying it over a lifetime. How... {i}heartbreaking{/i}."
    e "Enamorarse apenas un segundo y arrastrarlo durante toda una vida. Qué... {i}desgarrador{/i}."

# game/script.rpy:642
translate Spanish start_cupidkiss_c79aafe1:

    # e "I am Eros, God of Love, Sex and everything-in-between."
    e "Soy Eros, Dios del Amor, del Sexo y de todo lo que hay entre ambos."

# game/script.rpy:643
translate Spanish start_cupidkiss_7e3ee68b:

    # e "Tell me, child... would you give me your afterlife?"
    e "Dime, criatura... ¿me darías tu vida después de la muerte?"

# game/script.rpy:644
translate Spanish start_cupidkiss_244de13a:

    # e "Bring love to the hearts of those who yearn for it?"
    e "¿Llevarías amor a los corazones de quienes lo anhelan?"

# game/script.rpy:658
translate Spanish start_cupidkiss_f70b12fd:

    # e "I see why he likes you."
    e "Entiendo por qué le gustas."

# game/script.rpy:660
translate Spanish start_cupidkiss_15478649:

    # e "Go on, then."
    e "Adelante, entonces."

# game/script.rpy:675
translate Spanish start_cupidkiss_d57a07ac:

    # voice "heystranger"
    # v "Hey, stranger."
    voice "heystranger"
    v "Ey, tiempo sin verte."

# game/script.rpy:686
translate Spanish start_fadeintonothingness_a9122598:

    # e "So be it."
    e "Que así sea."

# game/script.rpy:687
translate Spanish start_fadeintonothingness_21199ff3:

    # e "Fade into nothingness."
    e "Desvanécete en la nada."

# game/script.rpy:688
translate Spanish start_fadeintonothingness_8fac9949:

    # e "Wander away, ever wondering what could have been."
    e "Vaga sin rumbo, preguntándote siempre qué habría podido ser."

# game/script.rpy:698
translate Spanish start_joylesslife_c4f42b04:

    # voice "areyoutrulyhappy"
    # v worried_talk "Are you truly happy?"
    voice "areyoutrulyhappy"
    v worried_talk "¿Eres feliz de verdad?"

# game/script.rpy:730
translate Spanish start_joylesslife_1c40dab3:

    # voice "areyoutellingme"
    # v shocked_talk "Are you telling me HQ made a mistake?"
    voice "areyoutellingme"
    v shocked_talk "¿Me estás diciendo que la central cometió un error?"

# game/script.rpy:741
translate Spanish start_yourproblem_d5cdb5fe:

    # voice "excuseme"
    # v angry_talk "Excuse me?"
    voice "excuseme"
    v angry_talk "¿Perdona?"

# game/script.rpy:750
translate Spanish start_yourproblem_1faa9ae2:

    # voice "areyousayingi"
    # v serious_talk "Are you saying I can't do it? That you're unfit for love?"
    voice "areyousayingi"
    v serious_talk "¿Estás diciendo que no puedo hacerlo? ¿Que el amor no es para ti?"

# game/script.rpy:770
translate Spanish start_ending_21b5ca91:

    # voice "thatsfair"
    # v amused_talk "That's… fair."
    voice "thatsfair"
    v amused_talk "Eso es... justo."

# game/script.rpy:774
translate Spanish start_ending_906c9ccb:

    # voice "thankyouithink"
    # v sarcastic_talk "Thank you. I think maybe that will be enough to satisfy them."
    voice "thankyouithink"
    v sarcastic_talk "Gracias. Creo que quizá con eso baste para dejarlos satisfechos."

# game/script.rpy:776
translate Spanish start_ending_e3789405:

    # voice "cantwaittorub"
    # v muhaha_talk "Can't wait to rub this on Valentine's nose."
    voice "cantwaittorub"
    v muhaha_talk "Me muero por restregárselo a Valentine en la cara."

# game/script.rpy:779
translate Spanish start_ending_3fa06e33:

    # voice "iguessyoureright"
    # v "I guess you're right."
    voice "iguessyoureright"
    v "Supongo que tienes razón."

# game/script.rpy:781
translate Spanish start_ending_2f6b6c1b:

    # voice "maybeitistime"
    # v "Maybe it is time to move on."
    voice "maybeitistime"
    v "Quizá sí sea hora de seguir adelante."

# game/script.rpy:784
translate Spanish start_ending_62b59d25:

    # voice "finallyfreefromeach"
    # v rueful_talk "Finally free from each other then?"
    voice "finallyfreefromeach"
    v rueful_talk "¿Entonces por fin nos libramos el uno del otro?"

# game/script.rpy:797
translate Spanish start_ending_4380c2dc:

    # voice "likewise"
    # v "Likewise."
    voice "likewise"
    v "Igualmente."

# game/script.rpy:802
translate Spanish start_ending_d6996bcf:

    # voice "iwishyouthe"
    # v rueful "I wish you the best."
    voice "iwishyouthe"
    v rueful "Te deseo lo mejor."

# game/script.rpy:808
translate Spanish start_ending_3587bb6a:

    # voice "onelastthing"
    # v worried_talk "One last thing."
    voice "onelastthing"
    v worried_talk "Una última cosa."

# game/script.rpy:810
translate Spanish start_ending_6842b94e:

    # voice "ihopeyourenot"
    # v serious_talk "I hope you're not going to swear off love forever?"
    voice "ihopeyourenot"
    v serious_talk "No vas a renunciar al amor para siempre, ¿verdad?"

# game/script.rpy:815
translate Spanish start_ending_109ce03b:

    # voice "itisyourchoice"
    # v rueful_talk "It is {i}your{/i} choice."
    voice "itisyourchoice"
    v rueful_talk "Es {i}tu{/i} decisión."

# game/script.rpy:817
translate Spanish start_ending_6edd28ff:

    # voice "sorryittookme"
    # v worried_talk "Sorry it took me this long to figure that out."
    voice "sorryittookme"
    v worried_talk "Perdona que me haya costado tanto darme cuenta."

# game/script.rpy:822
translate Spanish start_ending_109ce03b_1:

    # voice "itisyourchoice"
    # v rueful_talk "It is {i}your{/i} choice."
    voice "itisyourchoice"
    v rueful_talk "Es {i}tu{/i} decisión."

# game/script.rpy:824
translate Spanish start_ending_6edd28ff_1:

    # voice "sorryittookme"
    # v worried_talk "Sorry it took me this long to figure that out."
    voice "sorryittookme"
    v worried_talk "Perdona que me haya costado tanto darme cuenta."

# game/script.rpy:830
translate Spanish start_ending_98d47cf4:

    # voice "goodhopefullyyournext"
    # v rueful_talk "Good. Hopefully your next attempt will be tropeless and fraught with joy."
    voice "goodhopefullyyournext"
    v rueful_talk "Bien. Ojalá tu próximo intento esté libre de clichés y rebosante de alegría."

translate Spanish strings:

    # game/script.rpy:100
    old "{i}Excuse{/i} me?"
    new "¿{i}Perdona{/i}?"

    # game/script.rpy:107
    old "Wow, you're pretty."
    new "Guau, qué guapo eres."

    # game/script.rpy:114
    old "Did you just... materialise out of thin air?"
    new "¿Acabas de... materializarte de la nada?"

    # game/script.rpy:150
    old "Are those wings? Are you {i}floating{/i}?"
    new "¿Eso son alas? ¿Estás {i}flotando{/i}?"

    # game/script.rpy:158
    old "Who... or... {i}what{/i} are you?"
    new "¿Quién... o... {i}qué{/i} eres?"

    # game/script.rpy:161
    old "What the actual fuck?!"
    new "¡¿Pero qué carajos?!"

    # game/script.rpy:204
    old "{i}You’re{/i} the reason I keep getting stuck in confined spaces with randos?"
    new "¿{i}Tú{/i} eres el motivo de que siempre me encierren en espacios reducidos con desconocidos?"

    # game/script.rpy:209
    old "Creepy randos."
    new "Desconocidos raros."

    # game/script.rpy:216
    old "{i}You{/i} knew that. I did {i}not{/i}."
    new "{i}Tú{/i} lo sabías. Yo {i}no{/i}."

    # game/script.rpy:223
    old "What will it take for it to stop?"
    new "¿Qué hará falta para que pare?"

    # game/script.rpy:226
    old "What is it you {i}want{/i} from me?"
    new "¿Qué es lo que {i}quieres{/i} de mí?"

    # game/script.rpy:231
    old "Assuming I believe you... how can I help?"
    new "Suponiendo que te crea... ¿cómo puedo ayudar?"

    # game/script.rpy:245
    old "<Laugh in his face.>"
    new "<Reírme en su cara.>"

    # game/script.rpy:253
    old "You’re literally playing cupid."
    new "Estás literalmente jugando a ser cupido."

    # game/script.rpy:260
    old "Touchy, are we?"
    new "Qué sensible, ¿eh?"

    # game/script.rpy:267
    old "You can’t be serious."
    new "No puedes hablar en serio."

    # game/script.rpy:275
    old "I’m not against it, on principle."
    new "En principio, no estoy en contra."

    # game/script.rpy:288
    old "That long, huh? Barely noticed you there."
    new "¿Tanto tiempo, eh? Apenas te noté."

    # game/script.rpy:293
    old "I do, actually."
    new "De hecho, sí."

    # game/script.rpy:297
    old "Just to be clear, all those closets, lifts, basements, wine cellars... that was you?"
    new "Para que me quede claro: todos esos armarios, ascensores, sótanos, bodegas... ¿fuiste tú?"

    # game/script.rpy:302
    old "Kind of hard not to."
    new "Es difícil no hacerlo."

    # game/script.rpy:306
    old "Why, then?"
    new "¿Entonces por qué?"

    # game/script.rpy:311
    old "Did you have fun playing with {i}my{/i} life?"
    new "¿Te divertiste jugando con {i}mi{/i} vida?"

    # game/script.rpy:337
    old "You must not be very good at your job."
    new "No debes de ser muy bueno en tu trabajo."

    # game/script.rpy:346
    old "Someone’s feeling inadequate."
    new "Alguien se siente poca cosa."

    # game/script.rpy:349
    old "I'm not the problem here, pal."
    new "Yo no soy el problema aquí, amigo."

    # game/script.rpy:354
    old "There's no harm in admitting you've failed."
    new "No pasa nada por admitir que has fracasado."

    # game/script.rpy:357
    old "Maybe you're in over your head."
    new "Quizá esto te queda grande."

    # game/script.rpy:362
    old "There's no harm in asking for help."
    new "No pasa nada por pedir ayuda."

    # game/script.rpy:369
    old "I'm glad you reached out."
    new "Me alegra que hayas acudido a mí."

    # game/script.rpy:374
    old "You know what would help with that? Therapy."
    new "¿Sabes qué ayudaría con eso? Terapia."

    # game/script.rpy:384
    old "Limbo? Were you a human then?"
    new "¿El Limbo? ¿Eras humano entonces?"

    # game/script.rpy:394
    old "How do you get the gig then?"
    new "¿Y cómo consigues el puesto entonces?"

    # game/script.rpy:398
    old "Between that and playing Cupid, I'd pick aimless wandering."
    new "Entre eso y hacer de Cupido, prefiero vagar sin rumbo."

    # game/script.rpy:412
    old "Is a beating heart all it takes?"
    new "¿Basta con un corazón que lata?"

    # game/script.rpy:417
    old "Just because I'm alone, that doesn't mean it's a joyless life."
    new "Que no tenga pareja no significa que mi vida carezca de alegría."

    # game/script.rpy:421
    old "You know, this sounds a {i}lot{/i} like a You problem."
    new "¿Sabes? Esto suena {i}muchísimo{/i} a un problema tuyo."

    # game/script.rpy:441
    old "And you'll be my... {i}wingman{/i}?"
    new "¿Y vas a ser mi... {i}copiloto{/i}?"

    # game/script.rpy:448
    old "I'd really rather not."
    new "Preferiría que no."

    # game/script.rpy:461
    old "{i}Anyone{/i}? What about you?"
    new "¿{i}Cualquiera{/i}? ¿Y tú?"

    # game/script.rpy:471
    old "You said you were human once."
    new "Dijiste que alguna vez fuiste humano."

    # game/script.rpy:482
    old "Are you saying you {i}wouldn't{/i} be thrilled?"
    new "¿Estás diciendo que {i}no{/i} te emocionaría?"

    # game/script.rpy:494
    old "Good. I choose you."
    new "Bien. Te elijo a ti."

    # game/script.rpy:500
    old "I am. Are {i}you{/i} going to kiss shame me?"
    new "Hablo en serio. ¿Vas a juzgarme {i}tú{/i} por querer un beso?"

    # game/script.rpy:508
    old "Scared?"
    new "¿Miedo?"

    # game/script.rpy:519
    old "What's the worst that could happen?"
    new "¿Qué es lo peor que podría pasar?"

    # game/script.rpy:532
    old "Why {i}not{/i} you?"
    new "¿Por qué {i}no{/i} tú?"

    # game/script.rpy:535
    old "You said it was my choice. I choose you."
    new "Dijiste que era mi decisión. Te elijo a ti."

    # game/script.rpy:541
    old "I have a feeling your heart hasn't beaten in a while either."
    new "Tengo la impresión de que tu corazón tampoco late desde hace tiempo."

    # game/script.rpy:544
    old "Who knows, maybe the book is archaic about Cupids too."
    new "Quién sabe, quizá el libro también sea arcaico con los Cupidos."

    # game/script.rpy:547
    old "Maybe all it takes is a kiss and you'll get to move on."
    new "Quizá solo haga falta un beso y puedas seguir adelante."

    # game/script.rpy:551
    old "Us loveless gotta stick together, don't we?"
    new "Los 'Sinamor' tenemos que apoyarnos entre nosotros, ¿no?"

    # game/script.rpy:560
    old "If you really don't want to—"
    new "Si de verdad no quieres—"

    # game/script.rpy:571
    old "Gee, you really know how to make a person feel wanted."
    new "Vaya, sí que sabes hacer que una persona se sienta deseada."

    # game/script.rpy:639
    old "Who... are you?"
    new "¿Quién... eres?"

    # game/script.rpy:649
    old "I hear the pay is shit. Hard pass."
    new "Dicen que el sueldo es una mierda. Paso."

    # game/script.rpy:654
    old "Thanks, but no thanks. I want no part in your little hustle."
    new "Gracias, pero no, gracias. No quiero formar parte de tu tinglado."

    # game/script.rpy:657
    old "Bring it on."
    new "Vamos, inténtalo."

    # game/script.rpy:704
    old "Pretty much, yeah."
    new "Más o menos, sí."

    # game/script.rpy:708
    old "The reason your attempts have failed is likely because I’m not in need of your services."
    new "Lo más probable es que tus intentos hayan fallado porque no necesito tus servicios."

    # game/script.rpy:712
    old "My heart's seems to be beating just fine."
    new "Mi corazón parece latir perfectamente."

    # game/script.rpy:715
    old "Just not to the drum you set."
    new "Solo que no al ritmo que tú marcas."

    # game/script.rpy:718
    old "I'm still working on loving {i}myself{/i}."
    new "Aún estoy aprendiendo a quererme {i}a mí{/i}."

    # game/script.rpy:721
    old "That takes up enough energy without adding anyone else into the mix."
    new "Eso ya consume bastante energía sin añadir a nadie más a la mezcla."

    # game/script.rpy:724
    old "It's a work in progress."
    new "Es un trabajo en progreso."

    # game/script.rpy:727
    old "But staring all dopey-eyed at someone isn’t on my to-do list right now."
    new "Pero mirar a alguien con ojos de ensueño no está en mi lista de pendientes ahora mismo."

    # game/script.rpy:745
    old "From what you've said, you're not here because they're forcing you to be."
    new "Por lo que has dicho, no estás aquí porque te obliguen."

    # game/script.rpy:748
    old "You're here because of {i}pride{/i}."
    new "Estás aquí por {i}orgullo{/i}."

    # game/script.rpy:754
    old "I'm saying you should cough up and admit you're in over your head."
    new "Lo que digo es que deberías soltarlo y admitir que esto te queda grande."

    # game/script.rpy:759
    old "Give yourself the grace to not be perfect."
    new "Date permiso para no ser perfecto."

    # game/script.rpy:761
    old "Let yourself move on. Don't stay stuck just to prove a point."
    new "Permítete seguir adelante. No te quedes estancado solo para demostrar algo."

    # game/script.rpy:788
    old "It's been terrible not knowing you."
    new "Ha sido terrible no conocerte."

    # game/script.rpy:791
    old "10 out of 10 would do it again."
    new "10 de 10, lo volvería a hacer."

    # game/script.rpy:794
    old "10 out of 10 would {i}not{/i} do it again."
    new "10 de 10, {i}no{/i} lo volvería a hacer."

    # game/script.rpy:801
    old "Goodbye, Virgil."
    new "Adiós, Virgil."

    # game/script.rpy:814
    old "Yeah, I am."
    new "Sí, lo estoy."

    # game/script.rpy:821
    old "Maybe."
    new "Quizá."

    # game/script.rpy:829
    old "Nah."
    new "Nah."

