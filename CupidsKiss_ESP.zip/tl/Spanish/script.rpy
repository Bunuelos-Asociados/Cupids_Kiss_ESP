# TODO: Translation updated at 2026-10-12 16:24

# game/script.rpy:90
translate Spanish start_10fbfd3c:

    # voice "youreallycanttake"
    # v "You really can’t take a hint, can you?"
    voice "youreallycanttake"
    v "De verdad no captas las indirectas, ¿eh?"

# game/script.rpy:93
translate Spanish start_92ec929f:

    # "<I look up from the coffee stain I’m dabbing.>"
    "<Levanto la vista de la mancha de café que estoy secando con toquecitos.>"

# game/script.rpy:101
translate Spanish start_b4e4365c:

    # voice "youheardme"
    # v neutral_talk "You heard me."
    voice "youheardme"
    v neutral_talk "Me oíste."

# game/script.rpy:121
translate Spanish start_notblind_e5c8cb5e:

    # voice "guessyouarentblind"
    # v amused_talk "Guess you {i}aren’t{/i} blind."
    voice "guessyouarentblind"
    v amused_talk "Así que {i}sí{/i} ves bien."

# game/script.rpy:125
translate Spanish start_notblind_dde3f617:

    # voice "gladwecanfinally"
    # v sarcastic_talk "Glad we can finally rule that out."
    voice "gladwecanfinally"
    v sarcastic_talk "Me alegra poder descartarlo por fin."

# game/script.rpy:136
translate Spanish start_thefourthtime_a5230281:

    # voice "thatsthefourthtime"
    # v neutral_talk2 "That’s the fourth time this week that an unnaturally beautiful stranger has dumped their coffee on you."
    voice "thatsthefourthtime"
    v neutral_talk2 "Es la cuarta vez esta semana que un desconocido de una belleza sobrenatural te tira el café encima."

# game/script.rpy:138
translate Spanish start_thefourthtime_6b4bfa96:

    # voice "butdidyoubother"
    # v amused_talk "But did you bother looking at their face?"
    voice "butdidyoubother"
    v amused_talk "¿Pero te molestaste en mirarle la cara?"

# game/script.rpy:140
translate Spanish start_thefourthtime_54608835:

    # voice "flutteringyourlashes"
    # v sarcastic_talk "Fluttering your lashes?"
    voice "flutteringyourlashes"
    v sarcastic_talk "¿Aleteando las pestañas?"

# game/script.rpy:142
translate Spanish start_thefourthtime_8040df24:

    # voice "makingsmalltalk"
    # v serious_talk "Making small talk?"
    voice "makingsmalltalk"
    v serious_talk "¿Charlando de cosas triviales?"

# game/script.rpy:144
translate Spanish start_thefourthtime_8077bdec:

    # voice "itslikeyouretrying"
    # v angry_talk "It’s like you’re {i}trying{/i} to make my life harder."
    voice "itslikeyouretrying"
    v angry_talk "Es como si {i}intentaras{/i} complicarme la vida."

# game/script.rpy:152
translate Spanish start_thefourthtime_2e1174ea:

    # voice "darlingimgoingto"
    # v rueful_talk "Darling, I'm going to need you to accept a lot of bizarre things at face value."
    voice "darlingimgoingto"
    v rueful_talk "Cariño, voy a necesitar que aceptes muchas cosas extrañas tal como vienen."

# game/script.rpy:154
translate Spanish start_thefourthtime_664e63dc:

    # voice "ifyouregettingstuck"
    # v neutral_talk "If you're getting stuck on wings, we're going to have a problem."
    voice "ifyouregettingstuck"
    v neutral_talk "Si te atascas con lo de las alas, vamos a tener un problema."

# game/script.rpy:162
translate Spanish start_thefourthtime_acac4e1f:

    # voice "thatsmylinedear"
    # v serious_talk "That's my line, dear."
    voice "thatsmylinedear"
    v serious_talk "Esa es mi frase, cariño."

# game/script.rpy:167
translate Spanish start_imacupid_4b1b81ad:

    # voice "imnotsurehow"
    # v worried_talk "I'm not sure how long we have, so {i}try{/i} to keep up."
    voice "imnotsurehow"
    v worried_talk "No sé cuánto tiempo tenemos, así que {i}intenta{/i} seguirme el ritmo."

# game/script.rpy:169
translate Spanish start_imacupid_bb27df1a:

    # voice "mynameisvirgil"
    # v sarcastic_talk "My name is Virgil, I'm a Cupid and I'm at your service. Literally."
    voice "mynameisvirgil"
    v sarcastic_talk "Me llamo Virgil, soy un Cupido y estoy a tu servicio. Literalmente."

# game/script.rpy:171
translate Spanish start_imacupid_10003004:

    # voice "fiftyyearsofflawless"
    # v amused_talk "Fifty years of flawless work, rave reviews, not a single Loveless on my watch."
    voice "fiftyyearsofflawless"
    v amused_talk "Cincuenta años de trabajo impecable, reseñas excelentes y ni un solo 'Sinamor' bajo mi supervisión."

# game/script.rpy:173
translate Spanish start_imacupid_e1f5d10b:

    # voice "andthenyou"
    # v angry_talk "And then... {i}you{/i}."
    voice "andthenyou"
    v angry_talk "Y entonces... {i}tú{/i}."

# game/script.rpy:180
translate Spanish start_imacupid_f47e5ed8:

    # "<His finger gently taps me on the forehead.>"
    "<Su dedo me da un toquecito suave en la frente.>"

# game/script.rpy:187
translate Spanish start_imacupid_0e584474:

    # voice "ipullallthe"
    # v angry_talk "I pull all the stops: trapped in lifts, only one bed, reuniting with childhood crushes... the works."
    voice "ipullallthe"
    v angry_talk "Lo he intentado todo: atrapados en ascensores, una sola cama, reencuentros con amores de la infancia... el paquete completo."

# game/script.rpy:189
translate Spanish start_imacupid_cf3166f9:

    # voice "atthispointyour"
    # v sceptical_talk "At this point, your entire life is like an obnoxious rom-com."
    voice "atthispointyour"
    v sceptical_talk "A estas alturas, toda tu vida parece una comedia romántica insoportable."

# game/script.rpy:191
translate Spanish start_imacupid_6db6d580:

    # voice "butitslikeyou"
    # v angry_talk "But it's like you don't... notice. Or {i}care{/i}."
    voice "butitslikeyou"
    v angry_talk "Pero es como si no... te dieras cuenta. O no te {i}importara{/i}."

# game/script.rpy:193
translate Spanish start_imacupid_cb4cf1ff:

    # voice "whateverthecaseim"
    # v serious_talk "Whatever the case, I'm at my wits end."
    voice "whateverthecaseim"
    v serious_talk "Sea como sea, ya no sé qué más hacer."

# game/script.rpy:195
translate Spanish start_imacupid_7f8b5e79:

    # voice "ifigureditseither"
    # v sarcastic_talk "I figured it's either {i}this{/i} or admitting to HQ that I failed."
    voice "ifigureditseither"
    v sarcastic_talk "Pensé que era o {i}esto{/i} o admitir ante la central que fracasé."

# game/script.rpy:197
translate Spanish start_imacupid_adfdc61a:

    # voice "andidratherbe"
    # v muhaha_talk "And I'd rather be pulverised for rule breaking than give that condescending prick Valentine the satisfaction."
    voice "andidratherbe"
    v muhaha_talk "Y prefiero que me pulvericen por romper las reglas antes que darle esa satisfacción al cretino condescendiente de Valentine."

# game/script.rpy:199
translate Spanish start_imacupid_96711342:

    # voice "nowtellmewhat"
    # v neutral_talk "Now tell me: what are we going to do about this little snafu?"
    voice "nowtellmewhat"
    v neutral_talk "Ahora dime: ¿qué vamos a hacer con este pequeño enredo?"

# game/script.rpy:205
translate Spanish start_imacupid_317d05b1:

    # voice "handsomerandos"
    # v amused_talk "{i}Handsome{/i} randos."
    voice "handsomerandos"
    v amused_talk "Desconocidos {i}guapos{/i}."

# game/script.rpy:210
translate Spanish start_imacupid_7c6c47d9:

    # voice "ivettedthemfirst"
    # v sarcastic_talk "I vetted them first. They weren't creeps."
    voice "ivettedthemfirst"
    v sarcastic_talk "Los investigué antes. No eran unos raros."

# game/script.rpy:217
translate Spanish start_imacupid_3d09a081:

    # voice "ohicansee"
    # v shocked_talk "Oh. I can see now how that might be upsetting."
    voice "ohicansee"
    v shocked_talk "Oh. Ya veo cómo eso puede resultar molesto."

# game/script.rpy:219
translate Spanish start_imacupid_8b40e899:

    # voice "seethisiswhy"
    # v sarcastic_talk "See, {i}this{/i} is why this little chat is long overdue."
    voice "seethisiswhy"
    v sarcastic_talk "¿Ves? Por {i}esto{/i} esta charlita estaba más que pendiente."

# game/script.rpy:227
translate Spanish start_imacupid_e67afea4:

    # voice "isntthatobvious"
    # v sarcastic_talk "Isn't that obvious?"
    voice "isntthatobvious"
    v sarcastic_talk "¿No es obvio?"

# game/script.rpy:232
translate Spanish start_imacupid_c10537f5:

    # voice "ohthanksiappreciate"
    # v shocked_talk "Oh. Thanks, I appreciate that."
    voice "ohthanksiappreciate"
    v shocked_talk "Oh. Gracias, lo aprecio."

# game/script.rpy:234
translate Spanish start_imacupid_9a03db27:

    # voice "ihadafeeling"
    # v rueful_talk "I had a feeling you'd be less... understanding."
    voice "ihadafeeling"
    v rueful_talk "Tenía la sensación de que te lo tomarías con menos... comprensión."

# game/script.rpy:239
translate Spanish start_iwantyoutofallinlove_c79750a6:

    # voice "whatineedis"
    # v neutral_talk "What I {i}need{/i} is for you to fall in love already."
    voice "whatineedis"
    v neutral_talk "Lo que {i}necesito{/i} es que te enamores de una vez."

# game/script.rpy:246
translate Spanish start_iwantyoutofallinlove_f00942bd:

    # voice "hahayeshilarious"
    # v sarcastic_talk "Haha, yes, hilarious."
    voice "hahayeshilarious"
    v sarcastic_talk "Ja, ja, sí, graciosísimo."

# game/script.rpy:248
translate Spanish start_iwantyoutofallinlove_c9d04d46:

    # voice "imnotplayinghere"
    # v serious_talk "I’m not playing here."
    voice "imnotplayinghere"
    v serious_talk "No estoy jugando."

# game/script.rpy:255
translate Spanish start_iwantyoutofallinlove_9c3d7b6f:

    # voice "itsliterallymyjob"
    # v sceptical_talk "It’s {i}literally{/i} my job, ergo it doesn’t count as play."
    voice "itsliterallymyjob"
    v sceptical_talk "Es {i}literalmente{/i} mi trabajo, ergo no cuenta como jugar."

# game/script.rpy:261
translate Spanish start_iwantyoutofallinlove_97dc0eeb:

    # voice "ohshuddup"
    # v rueful_talk "Oh, shuddup."
    voice "ohshuddup"
    v rueful_talk "Ay, cállate."

# game/script.rpy:268
translate Spanish start_iwantyoutofallinlove_a5491a70:

    # voice "asaheartattack"
    # v neutral_talk2 "As a heart attack, my dear."
    voice "asaheartattack"
    v neutral_talk2 "Más en serio que un infarto, cariño."

# game/script.rpy:270
translate Spanish start_iwantyoutofallinlove_10cfe111:

    # voice "idealinlove"
    # v amused_talk "I deal in love and you’re one stingy customer."
    voice "idealinlove"
    v amused_talk "Yo vendo amor y tú no me compras ni una pizca."

# game/script.rpy:276
translate Spanish start_iwantyoutofallinlove_c7c662b2:

    # voice "thenwhyhaventyou"
    # v sarcastic_talk "Then why haven’t you fallen for anyone?!"
    voice "thenwhyhaventyou"
    v sarcastic_talk "¡¿Entonces por qué no te has enamorado de nadie?!"

# game/script.rpy:279
translate Spanish start_iwantyoutofallinlove_f895cb62:

    # voice "lookicantmove"
    # v serious_talk "Look, I can't move on to my next assignment until your stomach goes all aflutter."
    voice "lookicantmove"
    v serious_talk "Mira, no puedo pasar a mi siguiente misión hasta que sientas mariposas en el estómago."

# game/script.rpy:281
translate Spanish start_iwantyoutofallinlove_7d674882:

    # voice "itsnotjustfor"
    # v amused_talk "It's not just for me, I'm sure you're done with the tropey bullshit yourself."
    voice "itsnotjustfor"
    v amused_talk "No es solo por mí; seguro que a ti también te tiene hasta la coronilla toda esta mierda de clichés."

# game/script.rpy:283
translate Spanish start_iwantyoutofallinlove_e353a79f:

    # voice "iambeggingyou"
    # v worried_talk "I am {i}begging{/i} you. It’s been three months since I was assigned to you–"
    voice "iambeggingyou"
    v worried_talk "Te lo estoy {i}suplicando{/i}. Han pasado tres meses desde que me asignaron a ti–"

# game/script.rpy:289
translate Spanish start_iwantyoutofallinlove_077b8c11:

    # voice "imgladyoufind"
    # v amused_talk "I’m glad you find this funny."
    voice "imgladyoufind"
    v amused_talk "Qué bueno que te parezca gracioso."

# game/script.rpy:298
translate Spanish start_iwantyoutofallinlove_daaf731e:

    # voice "soyoudidnotice"
    # v muhaha blush "So you did notice."
    voice "soyoudidnotice"
    v muhaha blush "Así que sí te diste cuenta."

# game/script.rpy:310
translate Spanish start_iwantyoutofallinlove_eb8bf22c:

    # "<There's a pause, his face conflicted.>"
    "<Hay una pausa; su rostro refleja un conflicto.>"

# game/script.rpy:313
translate Spanish start_iwantyoutofallinlove_0f98d643:

    # voice "obviouslynot"
    # v serious "Obviously not."
    voice "obviouslynot"
    v serious "Obviamente no."

# game/script.rpy:316
translate Spanish start_iwantyoutofallinlove_fa8037d0:

    # voice "usuallyitsinand"        
    # v serious_talk "Usually it's in and out, one or two tropes max."
    voice "usuallyitsinand"        
    v serious_talk "Normalmente es entrar y salir: uno o dos clichés como máximo."

# game/script.rpy:318
translate Spanish start_iwantyoutofallinlove_7b117e0b:

    # voice "butwithyounothing"
    # v worried_talk blush "But with you... nothing was working, so I doubled down."
    voice "butwithyounothing"
    v worried_talk blush "Pero contigo... nada funcionaba, así que redoblé la apuesta."

# game/script.rpy:323
translate Spanish start_iwantyoutofallinlove_ac7922f1:

    # voice "ishouldprobablyhave"
    # v serious_talk "I should probably have stopped, but I didn't want to admit I was struggling."
    voice "ishouldprobablyhave"
    v serious_talk "Seguramente debí parar, pero no quería admitir que me estaba costando."

# game/script.rpy:325
translate Spanish start_iwantyoutofallinlove_5b183188:

    # voice "andyougotcaught"
    # v rueful_talk "And you got caught in the middle."
    voice "andyougotcaught"
    v rueful_talk "Y tú quedaste en medio de todo."

# game/script.rpy:331
translate Spanish start_iwantyoutofallinlove_3c53e896:

    # voice "iamsorry"
    # v serious_talk "I {i}am{/i} sorry."
    voice "iamsorry"
    v serious_talk "De verdad {i}lo siento{/i}."

# game/script.rpy:333
translate Spanish start_iwantyoutofallinlove_2cbb4f44:

    # voice "iknowitsbeen"
    # v worried_talk "I know it's been a {i}lot{/i}."
    voice "iknowitsbeen"
    v worried_talk "Sé que ha sido {i}mucho{/i}."

# game/script.rpy:338
translate Spanish start_iwantyoutofallinlove_5251d7b5:

    # voice "ibegyourpardon"
    # v angry_talk "I beg your pardon, I’m {i}excellent{/i} at my job."
    voice "ibegyourpardon"
    v angry_talk "Perdona, soy {i}excelente{/i} en mi trabajo."

# game/script.rpy:340
translate Spanish start_iwantyoutofallinlove_39c92f71:

    # voice "youretheonewhos"
    # v serious_talk "You’re the one who’s... defective."
    voice "youretheonewhos"
    v serious_talk "Quien tiene un... defecto de fábrica eres tú."

# game/script.rpy:342
translate Spanish start_iwantyoutofallinlove_23806136:

    # voice "probably"
    # v worried_talk "Probably."
    voice "probably"
    v worried_talk "Probablemente."

# game/script.rpy:358
translate Spanish start_iwantyoutofallinlove_6ea1f2d7:

    # voice "maybeiam"
    # v worried_talk "Maybe I am."
    voice "maybeiam"
    v worried_talk "Quizá lo sea."

# game/script.rpy:363
translate Spanish start_iwantyoutofallinlove_cc46ab98:

    # voice "iknowyoudthink"
    # v rueful_talk "I know. You'd think after fifty years it'd get easier, but it hasn't."
    voice "iknowyoudthink"
    v rueful_talk "Lo sé. Uno pensaría que tras cincuenta años sería más fácil, pero no."

# game/script.rpy:370
translate Spanish start_iwantyoutofallinlove_f906e587:

    # voice "imgladtooyou"
    # v rueful_talk "I'm glad too. You make it palatable."
    voice "imgladtooyou"
    v rueful_talk "Yo también me alegro. Tú lo haces más llevadero."

# game/script.rpy:375
translate Spanish start_iwantyoutofallinlove_2d46201a:

    # voice "yeahlimboisntbig"
    # v rueful_talk "Yeahhhh, Limbo isn't big on mental health."
    voice "yeahlimboisntbig"
    v rueful_talk "Sííí, al Limbo no le va mucho eso de la salud mental."

# game/script.rpy:377
translate Spanish start_iwantyoutofallinlove_ac152fbb:

    # voice "ifwegotover"
    # v sarcastic_talk "If we got over our problems, we'd just move on and they'd lose their free labour."
    voice "ifwegotover"
    v sarcastic_talk "Si superáramos nuestros problemas, seguiríamos adelante y perderían su mano de obra gratis."

# game/script.rpy:379
translate Spanish start_iwantyoutofallinlove_2317ba48:

    # voice "canthavethatcan"
    # v rueful_talk "Can't have that, can we?"
    voice "canthavethatcan"
    v rueful_talk "No podemos permitirlo, ¿verdad?"

# game/script.rpy:388
translate Spanish start_iwantyoutofallinlove_d6cc2564:

    # voice "alifetimeago"
    # v rueful_talk "A lifetime ago."
    voice "alifetimeago"
    v rueful_talk "Hace toda una vida."

# game/script.rpy:390
translate Spanish start_iwantyoutofallinlove_9151a678:

    # voice "igotluckymost"
    # v serious_talk "I got lucky. Most of the people there wander aimlessly for all eternity."
    voice "igotluckymost"
    v serious_talk "Tuve suerte. La mayoría de la gente de allí vaga sin rumbo por toda la eternidad."

# game/script.rpy:395
translate Spanish start_iwantyoutofallinlove_75b67678:

    # voice "itsmyjobto"
    # v amused_talk "It's my job to ensure you never get the chance to find out."
    voice "itsmyjobto"
    v amused_talk "Mi trabajo es asegurarme de que nunca tengas la oportunidad de averiguarlo."

# game/script.rpy:399
translate Spanish start_iwantyoutofallinlove_811ded4f:

    # voice "definitelypaysbetter"
    # v amused_talk "Definitely pays better."
    voice "definitelypaysbetter"
    v amused_talk "Desde luego, paga mejor."

# game/script.rpy:403
translate Spanish start_iwantyoutofallinlove_bfbbf026:

    # voice "regardlesswerestucktogether"
    # v sarcastic_talk "Regardless, we’re stuck together until we can get your dead heart beating again."
    voice "regardlesswerestucktogether"
    v sarcastic_talk "Sea como sea, estamos atados hasta que logremos que tu corazón muerto vuelva a latir."

# game/script.rpy:405
translate Spanish start_iwantyoutofallinlove_0bd555fb:

    # voice "andimsureyou"
    # v rueful_talk "And I'm sure you share my desire to get unstuck as soon as possible."
    voice "andimsureyou"
    v rueful_talk "Y seguro que compartes mi deseo de desatarnos cuanto antes."

# game/script.rpy:429
translate Spanish start_beatingheart_151b0bfa:

    # voice "atthispointid"
    # v sceptical_talk "At this point I'd settle for a dumb crush."
    voice "atthispointid"
    v sceptical_talk "A estas alturas me conformaría con un simple enamoramiento tonto."

# game/script.rpy:431
translate Spanish start_beatingheart_a4ee912a:

    # voice "hellanenthusiasticsnog"
    # v sarcastic_talk "Hell, an enthusiastic snog."
    voice "hellanenthusiasticsnog"
    v sarcastic_talk "Demonios, hasta con un beso apasionado."

# game/script.rpy:433
translate Spanish start_beatingheart_e771a219:

    # voice "itshouldbefalling"
    # v muhaha_talk "It {i}should{/i} be falling in love, but the rules are positively medieval and I'm past caring."
    voice "itshouldbefalling"
    v muhaha_talk "{i}Debería{/i} ser enamorarte, pero las reglas son francamente medievales y ya me da igual."

# game/script.rpy:435
translate Spanish start_beatingheart_a906b2d3:

    # voice "justpickanyoneyoure"
    # v amused_talk "Just pick anyone you’re vaguely attracted to."
    voice "justpickanyoneyoure"
    v amused_talk "Elige a cualquiera que te atraiga aunque sea un poco."

# game/script.rpy:443
translate Spanish start_kisschoice_97f7debd:

    # voice "hilarious"
    # v sarcastic_talk "{i}Hilarious{/i}."
    voice "hilarious"
    v sarcastic_talk "{i}Graciosísimo{/i}."

# game/script.rpy:449
translate Spanish start_kisschoice_508a6cef:

    # voice "wellthenidbest"
    # v amused_talk "Well, then I'd best get comfortable."
    voice "wellthenidbest"
    v amused_talk "Bueno, entonces será mejor que me ponga cómodo."

# game/script.rpy:451
translate Spanish start_kisschoice_72fb4b65:

    # voice "whatstheaveragehuman"
    # v sarcastic_talk "What's the average human lifespan nowadays?"
    voice "whatstheaveragehuman"
    v sarcastic_talk "¿Cuál es la esperanza de vida humana promedio hoy en día?"

# game/script.rpy:453
translate Spanish start_kisschoice_5897898d:

    # voice "100years"
    # v muhaha_talk "100 years?"
    voice "100years"
    v muhaha_talk "¿100 años?"

# game/script.rpy:455
translate Spanish start_kisschoice_b2efb302:

    # voice "shouldgobyin"
    # v sarcastic_talk "Should go by in a jiffy."
    voice "shouldgobyin"
    v sarcastic_talk "Pasará en un suspiro."

# game/script.rpy:466
translate Spanish start_cupidkiss_328635db:

    # voice "meumimnot"
    # v shocked_talk blush "Me?! Uhm, I'm not sure I qualify–"
    voice "meumimnot"
    v shocked_talk blush "¡¿Yo?! Eh, no estoy seguro de calificar–"

# game/script.rpy:474
translate Spanish start_cupidkiss_fa57ba9a:

    # voice "yesbeforeidied"
    # v worried_talk "Yes, {i}before{/i} I died."
    voice "yesbeforeidied"
    v worried_talk "Sí, {i}antes{/i} de morir."

# game/script.rpy:477
translate Spanish start_cupidkiss_0e82a4fb:

    # voice "darlingtheresplentyof"
    # v rueful_talk "Darling, there's plenty of viable, {i}living{/i} candidates who would be thrilled to kiss you–"
    voice "darlingtheresplentyof"
    v rueful_talk "Cariño, hay muchísimos candidatos viables y {i}vivos{/i} a los que les encantaría besarte–"

# game/script.rpy:485
translate Spanish start_cupidkiss_d71c05cf:

    # voice "ofcourseiwould"
    # v worried_talk "Of course I would!"
    voice "ofcourseiwould"
    v worried_talk "¡Claro que sí!"

# game/script.rpy:487
translate Spanish start_cupidkiss_ba2b8310:

    # voice "ijustdontthink"
    # v rueful_talk "I just don't think you’re clear on the possibilities."
    voice "ijustdontthink"
    v rueful_talk "Es solo que no creo que tengas claras las posibilidades."

# game/script.rpy:489
translate Spanish start_cupidkiss_5d769e2d:

    # voice "justpickaperson"
    # v worried_talk "Just pick a person, {i}any{/i} person and I'll make it happen."
    voice "justpickaperson"
    v worried_talk "Elige a una persona, {i}cualquiera{/i}, y yo lo haré realidad."

# game/script.rpy:496
translate Spanish start_cupidkiss_15d4071b:

    # voice "ithoughtyousaid"
    # v rueful_talk "I thought you said you're discerning."
    voice "ithoughtyousaid"
    v rueful_talk "Creía que habías dicho que eras exigente."

# game/script.rpy:503
translate Spanish start_cupidkiss_ea1123e0:

    # voice "7.9billionpeopleim"
    # v serious_talk "7.9 billion people. I'm offering you {i}any{/i} person in the world on a silver platter–"
    voice "7.9billionpeopleim"
    v serious_talk "7.900 millones de personas. Te ofrezco a {i}cualquiera{/i} del mundo en bandeja de plata–"

# game/script.rpy:509
translate Spanish start_cupidkiss_64d74722:

    # voice "amnot"
    # v angry_talk "Am not!"
    voice "amnot"
    v angry_talk "¡Que no!"

# game/script.rpy:511
translate Spanish start_cupidkiss_94938d57:

    # voice "well"
    # v worried_talk "Well."
    voice "well"
    v worried_talk "Bueno."

# game/script.rpy:513
translate Spanish start_cupidkiss_e4788a51:

    # voice "maybe"
    # v rueful_talk "{i}Maybe{/i}."
    voice "maybe"
    v rueful_talk "{i}Quizá{/i}."

# game/script.rpy:525
translate Spanish start_cupidkiss_9f6c65ef:

    # "He swallows and my heart thumps wildly in my chest."
    "Traga saliva y mi corazón late desbocado en mi pecho."

# game/script.rpy:527
translate Spanish start_cupidkiss_f630e503:

    # voice "whyme"
    # v worried_talk "Why {i}me{/i}?"
    voice "whyme"
    v worried_talk "¿Por qué {i}yo{/i}?"

# game/script.rpy:536
translate Spanish start_cupidkiss_77b7a9e9:

    # voice "isayalot"
    # v rueful_talk "I say a {i}lot{/i} of things."
    voice "isayalot"
    v rueful_talk "Digo {i}muchas{/i} cosas."

# game/script.rpy:555
translate Spanish start_cupidkiss_56cd47ab:

    # voice "but"
    # v worried_talk "But–"
    voice "but"
    v worried_talk "Pero–"

# game/script.rpy:563
translate Spanish start_cupidkiss_981c3f3b:

    # voice "ohiwantto"
    # v worried_talk "Oh, I want to."
    voice "ohiwantto"
    v worried_talk "Oh, claro que quiero."

# game/script.rpy:565
translate Spanish start_cupidkiss_e401ee3e:

    # voice "ijusthinkits"
    # v rueful_talk "I just think it's a terrible idea."
    voice "ijusthinkits"
    v rueful_talk "Es solo que me parece una idea pésima."

# game/script.rpy:574
translate Spanish start_cupidkiss_74982199:

    # voice "imafewcenturies"
    # v amused_talk "I'm a few centuries out of practice."
    voice "imafewcenturies"
    v amused_talk "Llevo unos cuantos siglos sin practicar."

# game/script.rpy:577
translate Spanish start_cupidkiss_66bc6d15:

    # voice "yourelovelytruly"
    # v rueful_talk "You're... lovely. {i}Truly{/i}."
    voice "yourelovelytruly"
    v rueful_talk "Eres... un encanto. {i}De verdad{/i}."

# game/script.rpy:589
translate Spanish start_cupidkiss_b562f6bd:

    # "I gently comb my fingers through the hair at the nape of his neck."
    "Paso suavemente los dedos por el cabello de su nuca."

# game/script.rpy:594
translate Spanish start_cupidkiss_74f91b20:

    # "He leans into me, putting his forehead to mine."
    "Se inclina hacia mí y apoya su frente en la mía."

# game/script.rpy:598
translate Spanish start_cupidkiss_392f03a3:

    # "I wonder if I'll miss it, the presence I never even knew was there."
    "Me pregunto si lo echaré de menos, esa presencia que ni siquiera sabía que estaba ahí."

# game/script.rpy:606
translate Spanish start_cupidkiss_f1896b20:

    # "The smile I've only just seen, but seems somehow... familiar."
    "La sonrisa que acabo de ver, pero que de algún modo... me resulta familiar."

# game/script.rpy:611
translate Spanish start_cupidkiss_76319bcd:

    # "It feels {i}right{/i}."
    "Se siente {i}bien{/i}."

# game/script.rpy:626
translate Spanish start_cupidkiss_37ba86f2:

    # n "A lifetime later..."
    n "Toda una vida después..."

# game/script.rpy:634
translate Spanish start_cupidkiss_0dfd4660:

    # e "The cruellest of fates."
    e "El más cruel de los destinos."

# game/script.rpy:635
translate Spanish start_cupidkiss_5431a2bd:

    # e "The most bruised of souls."
    e "La más magullada de las almas."

# game/script.rpy:636
translate Spanish start_cupidkiss_ca5abf1d:

    # e "Falling in love for just a second and carrying it over a lifetime. How... {i}heartbreaking{/i}."
    e "Enamorarse apenas un segundo y arrastrarlo durante toda una vida. Qué... {i}desgarrador{/i}."

# game/script.rpy:642
translate Spanish start_cupidkiss_c79aafe1:

    # e "I am Eros, God of Love, Sex and everything-in-between."
    e "Soy Eros, Dios del Amor, del Sexo y de todo lo que hay entre ambos."

# game/script.rpy:643
translate Spanish start_cupidkiss_7e3ee68b:

    # e "Tell me, child... would you give me your afterlife?"
    e "Dime, criatura... ¿me darías tu vida después de la muerte?"

# game/script.rpy:644
translate Spanish start_cupidkiss_244de13a:

    # e "Bring love to the hearts of those who yearn for it?"
    e "¿Llevarías amor a los corazones de quienes lo anhelan?"

# game/script.rpy:658
translate Spanish start_cupidkiss_f70b12fd:

    # e "I see why he likes you."
    e "Entiendo por qué le gustas."

# game/script.rpy:660
translate Spanish start_cupidkiss_15478649:

    # e "Go on, then."
    e "Adelante, entonces."

# game/script.rpy:675
translate Spanish start_cupidkiss_7e041c73:

    # voice "heystranger"
    # v "Hey, stranger."
    voice "heystranger"
    v "Ey, tiempo sin verte."

# game/script.rpy:686
translate Spanish start_fadeintonothingness_a9122598:

    # e "So be it."
    e "Que así sea."

# game/script.rpy:687
translate Spanish start_fadeintonothingness_21199ff3:

    # e "Fade into nothingness."
    e "Desvanécete en la nada."

# game/script.rpy:688
translate Spanish start_fadeintonothingness_8fac9949:

    # e "Wander away, ever wondering what could have been."
    e "Vaga sin rumbo, preguntándote siempre qué habría podido ser."

# game/script.rpy:698
translate Spanish start_joylesslife_15845b2c:

    # voice "areyoutrulyhappy"
    # v worried_talk "Are you truly happy?"
    voice "areyoutrulyhappy"
    v worried_talk "¿Eres feliz de verdad?"

# game/script.rpy:730
translate Spanish start_joylesslife_5d5d4699:

    # voice "areyoutellingme"
    # v shocked_talk "Are you telling me HQ made a mistake?"
    voice "areyoutellingme"
    v shocked_talk "¿Me estás diciendo que la central cometió un error?"

# game/script.rpy:741
translate Spanish start_yourproblem_054b7bbf:

    # voice "excuseme"
    # v angry_talk "Excuse me?"
    voice "excuseme"
    v angry_talk "¿Perdona?"

# game/script.rpy:750
translate Spanish start_yourproblem_8ebf3aec:

    # voice "areyousayingi"
    # v serious_talk "Are you saying I can't do it? That you're unfit for love?"
    voice "areyousayingi"
    v serious_talk "¿Estás diciendo que no puedo hacerlo? ¿Que el amor no es para ti?"

# game/script.rpy:770
translate Spanish start_ending_44bfd42d:

    # voice "thatsfair"
    # v amused_talk "That's… fair."
    voice "thatsfair"
    v amused_talk "Eso es... justo."

# game/script.rpy:774
translate Spanish start_ending_9075550d:

    # voice "thankyouithink"
    # v sarcastic_talk "Thank you. I think maybe that will be enough to satisfy them."
    voice "thankyouithink"
    v sarcastic_talk "Gracias. Creo que quizá con eso baste para dejarlos satisfechos."

# game/script.rpy:776
translate Spanish start_ending_68d39306:

    # voice "cantwaittorub"
    # v muhaha_talk "Can't wait to rub this on Valentine's nose."
    voice "cantwaittorub"
    v muhaha_talk "Me muero por restregárselo a Valentine en la cara."

# game/script.rpy:779
translate Spanish start_ending_9b857705:

    # voice "iguessyoureright"
    # v "I guess you're right."
    voice "iguessyoureright"
    v "Supongo que tienes razón."

# game/script.rpy:781
translate Spanish start_ending_997176e2:

    # voice "maybeitistime"
    # v "Maybe it is time to move on."
    voice "maybeitistime"
    v "Quizá sí sea hora de seguir adelante."

# game/script.rpy:784
translate Spanish start_ending_79bc4459:

    # voice "finallyfreefromeach"
    # v rueful_talk "Finally free from each other then?"
    voice "finallyfreefromeach"
    v rueful_talk "¿Entonces por fin nos libramos el uno del otro?"

# game/script.rpy:797
translate Spanish start_ending_3d6ea40e:

    # voice "likewise"
    # v "Likewise."
    voice "likewise"
    v "Igualmente."

# game/script.rpy:802
translate Spanish start_ending_730742cb:

    # voice "iwishyouthe"
    # v rueful "I wish you the best."
    voice "iwishyouthe"
    v rueful "Te deseo lo mejor."

# game/script.rpy:808
translate Spanish start_ending_6fea268d:

    # voice "onelastthing"
    # v worried_talk "One last thing."
    voice "onelastthing"
    v worried_talk "Una última cosa."

# game/script.rpy:810
translate Spanish start_ending_3d62af0d:

    # voice "ihopeyourenot"
    # v serious_talk "I hope you're not going to swear off love forever?"
    voice "ihopeyourenot"
    v serious_talk "No vas a renunciar al amor para siempre, ¿verdad?"

# game/script.rpy:815
translate Spanish start_ending_10530402:

    # voice "itisyourchoice"
    # v rueful_talk "It is {i}your{/i} choice."
    voice "itisyourchoice"
    v rueful_talk "Es {i}tu{/i} decisión."

# game/script.rpy:817
translate Spanish start_ending_b516d6e8:

    # voice "sorryittookme"
    # v worried_talk "Sorry it took me this long to figure that out."
    voice "sorryittookme"
    v worried_talk "Perdona que me haya costado tanto darme cuenta."

# game/script.rpy:822
translate Spanish start_ending_10530402_1:

    # voice "itisyourchoice"
    # v rueful_talk "It is {i}your{/i} choice."
    voice "itisyourchoice"
    v rueful_talk "Es {i}tu{/i} decisión."

# game/script.rpy:824
translate Spanish start_ending_b516d6e8_1:

    # voice "sorryittookme"
    # v worried_talk "Sorry it took me this long to figure that out."
    voice "sorryittookme"
    v worried_talk "Perdona que me haya costado tanto darme cuenta."

# game/script.rpy:830
translate Spanish start_ending_a5d64629:

    # voice "goodhopefullyyournext"
    # v rueful_talk "Good. Hopefully your next attempt will be tropeless and fraught with joy."
    voice "goodhopefullyyournext"
    v rueful_talk "Bien. Ojalá tu próximo intento esté libre de clichés y rebosante de alegría."

translate Spanish strings:

    # game/script.rpy:99
    old "{i}Excuse{/i} me?"
    new "¿{i}Perdona{/i}?"

    # game/script.rpy:99
    old "Wow, you're pretty."
    new "Guau, qué guapo eres."

    # game/script.rpy:99
    old "Did you just... materialise out of thin air?"
    new "¿Acabas de... materializarte de la nada?"

    # game/script.rpy:148
    old "Are those wings? Are you {i}floating{/i}?"
    new "¿Eso son alas? ¿Estás {i}flotando{/i}?"

    # game/script.rpy:148
    old "Who... or... {i}what{/i} are you?"
    new "¿Quién... o... {i}qué{/i} eres?"

    # game/script.rpy:148
    old "What the actual fuck?!"
    new "¡¿Pero qué carajos?!"

    # game/script.rpy:203
    old "{i}You’re{/i} the reason I keep getting stuck in confined spaces with randos?"
    new "¿{i}Tú{/i} eres el motivo de que siempre me encierren en espacios reducidos con desconocidos?"

    # game/script.rpy:203
    old "What is it you {i}want{/i} from me?"
    new "¿Qué es lo que {i}quieres{/i} de mí?"

    # game/script.rpy:203
    old "Assuming I believe you... how can I help?"
    new "Suponiendo que te crea... ¿cómo puedo ayudar?"

    # game/script.rpy:208
    old "Creepy randos."
    new "Desconocidos raros."

    # game/script.rpy:215
    old "{i}You{/i} knew that. I did {i}not{/i}."
    new "{i}Tú{/i} lo sabías. Yo {i}no{/i}."

    # game/script.rpy:222
    old "What will it take for it to stop?"
    new "¿Qué hará falta para que pare?"

    # game/script.rpy:243
    old "<Laugh in his face.>"
    new "<Reírme en su cara.>"

    # game/script.rpy:243
    old "You can’t be serious."
    new "No puedes hablar en serio."

    # game/script.rpy:243
    old "I’m not against it, on principle."
    new "En principio, no estoy en contra."

    # game/script.rpy:252
    old "You’re literally playing cupid."
    new "Estás literalmente jugando a ser cupido."

    # game/script.rpy:259
    old "Touchy, are we?"
    new "Qué sensible, ¿eh?"

    # game/script.rpy:287
    old "That long, huh? Barely noticed you there."
    new "¿Tanto tiempo, eh? Apenas te noté."

    # game/script.rpy:287
    old "Just to be clear, all those closets, lifts, basements, wine cellars... that was you?"
    new "Para que me quede claro: todos esos armarios, ascensores, sótanos, bodegas... ¿fuiste tú?"

    # game/script.rpy:287
    old "You must not be very good at your job."
    new "No debes de ser muy bueno en tu trabajo."

    # game/script.rpy:292
    old "I do, actually."
    new "De hecho, sí."

    # game/script.rpy:301
    old "Kind of hard not to."
    new "Es difícil no hacerlo."

    # game/script.rpy:305
    old "Why, then?"
    new "¿Entonces por qué?"

    # game/script.rpy:305
    old "Did you have fun playing with {i}my{/i} life?"
    new "¿Te divertiste jugando con {i}mi{/i} vida?"

    # game/script.rpy:345
    old "Someone’s feeling inadequate."
    new "Alguien se siente poca cosa."

    # game/script.rpy:345
    old "I'm not the problem here, pal."
    new "Yo no soy el problema aquí, amigo."

    # game/script.rpy:353
    old "There's no harm in admitting you've failed."
    new "No pasa nada por admitir que has fracasado."

    # game/script.rpy:353
    old "There's no harm in asking for help."
    new "No pasa nada por pedir ayuda."

    # game/script.rpy:356
    old "Maybe you're in over your head."
    new "Quizá esto te queda grande."

    # game/script.rpy:367
    old "I'm glad you reached out."
    new "Me alegra que hayas acudido a mí."

    # game/script.rpy:367
    old "You know what would help with that? Therapy."
    new "¿Sabes qué ayudaría con eso? Terapia."

    # game/script.rpy:383
    old "Limbo? Were you a human then?"
    new "¿El Limbo? ¿Eras humano entonces?"

    # game/script.rpy:393
    old "How do you get the gig then?"
    new "¿Y cómo consigues el puesto entonces?"

    # game/script.rpy:393
    old "Between that and playing Cupid, I'd pick aimless wandering."
    new "Entre eso y hacer de Cupido, prefiero vagar sin rumbo."

    # game/script.rpy:411
    old "Is a beating heart all it takes?"
    new "¿Basta con un corazón que lata?"

    # game/script.rpy:411
    old "Just because I'm alone, that doesn't mean it's a joyless life."
    new "Que no tenga pareja no significa que mi vida carezca de alegría."

    # game/script.rpy:411
    old "You know, this sounds a {i}lot{/i} like a You problem."
    new "¿Sabes? Esto suena {i}muchísimo{/i} a un problema tuyo."

    # game/script.rpy:440
    old "And you'll be my... {i}wingman{/i}?"
    new "¿Y vas a ser mi... {i}copiloto{/i}?"

    # game/script.rpy:440
    old "I'd really rather not."
    new "Preferiría que no."

    # game/script.rpy:440
    old "{i}Anyone{/i}? What about you?"
    new "¿{i}Cualquiera{/i}? ¿Y tú?"

    # game/script.rpy:470
    old "You said you were human once."
    new "Dijiste que alguna vez fuiste humano."

    # game/script.rpy:481
    old "Are you saying you {i}wouldn't{/i} be thrilled?"
    new "¿Estás diciendo que {i}no{/i} te emocionaría?"

    # game/script.rpy:493
    old "Good. I choose you."
    new "Bien. Te elijo a ti."

    # game/script.rpy:493
    old "Scared?"
    new "¿Miedo?"

    # game/script.rpy:493
    old "What's the worst that could happen?"
    new "¿Qué es lo peor que podría pasar?"

    # game/script.rpy:499
    old "I am. Are {i}you{/i} going to kiss shame me?"
    new "Hablo en serio. ¿Vas a juzgarme {i}tú{/i} por querer un beso?"

    # game/script.rpy:531
    old "Why {i}not{/i} you?"
    new "¿Por qué {i}no{/i} tú?"

    # game/script.rpy:531
    old "I have a feeling your heart hasn't beaten in a while either."
    new "Tengo la impresión de que tu corazón tampoco late desde hace tiempo."

    # game/script.rpy:531
    old "Us loveless gotta stick together, don't we?"
    new "Los 'Sinamor' tenemos que apoyarnos entre nosotros, ¿no?"

    # game/script.rpy:534
    old "You said it was my choice. I choose you."
    new "Dijiste que era mi decisión. Te elijo a ti."

    # game/script.rpy:543
    old "Who knows, maybe the book is archaic about Cupids too."
    new "Quién sabe, quizá el libro también sea arcaico con los Cupidos."

    # game/script.rpy:546
    old "Maybe all it takes is a kiss and you'll get to move on."
    new "Quizá solo haga falta un beso y puedas seguir adelante."

    # game/script.rpy:559
    old "If you really don't want to—"
    new "Si de verdad no quieres—"

    # game/script.rpy:569
    old "Gee, you really know how to make a person feel wanted."
    new "Vaya, sí que sabes hacer que una persona se sienta deseada."

    # game/script.rpy:638
    old "Who... are you?"
    new "¿Quién... eres?"

    # game/script.rpy:648
    old "I hear the pay is shit. Hard pass."
    new "Dicen que el sueldo es una mierda. Paso."

    # game/script.rpy:648
    old "Thanks, but no thanks. I want no part in your little hustle."
    new "Gracias, pero no, gracias. No quiero formar parte de tu tinglado."

    # game/script.rpy:648
    old "Bring it on."
    new "Vamos, inténtalo."

    # game/script.rpy:703
    old "Pretty much, yeah."
    new "Más o menos, sí."

    # game/script.rpy:703
    old "I'm still working on loving {i}myself{/i}."
    new "Aún estoy aprendiendo a quererme {i}a mí{/i}."

    # game/script.rpy:703
    old "It's a work in progress."
    new "Es un trabajo en progreso."

    # game/script.rpy:707
    old "The reason your attempts have failed is likely because I’m not in need of your services."
    new "Lo más probable es que tus intentos hayan fallado porque no necesito tus servicios."

    # game/script.rpy:711
    old "My heart's seems to be beating just fine."
    new "Mi corazón parece latir perfectamente."

    # game/script.rpy:714
    old "Just not to the drum you set."
    new "Solo que no al ritmo que tú marcas."

    # game/script.rpy:720
    old "That takes up enough energy without adding anyone else into the mix."
    new "Eso ya consume bastante energía sin añadir a nadie más a la mezcla."

    # game/script.rpy:726
    old "But staring all dopey-eyed at someone isn’t on my to-do list right now."
    new "Pero mirar a alguien con ojos de ensueño no está en mi lista de pendientes ahora mismo."

    # game/script.rpy:744
    old "From what you've said, you're not here because they're forcing you to be."
    new "Por lo que has dicho, no estás aquí porque te obliguen."

    # game/script.rpy:747
    old "You're here because of {i}pride{/i}."
    new "Estás aquí por {i}orgullo{/i}."

    # game/script.rpy:753
    old "I'm saying you should cough up and admit you're in over your head."
    new "Lo que digo es que deberías soltarlo y admitir que esto te queda grande."

    # game/script.rpy:758
    old "Give yourself the grace to not be perfect."
    new "Date permiso para no ser perfecto."

    # game/script.rpy:758
    old "Let yourself move on. Don't stay stuck just to prove a point."
    new "Permítete seguir adelante. No te quedes estancado solo para demostrar algo."

    # game/script.rpy:787
    old "It's been terrible not knowing you."
    new "Ha sido terrible no conocerte."

    # game/script.rpy:787
    old "Goodbye, Virgil."
    new "Adiós, Virgil."

    # game/script.rpy:790
    old "10 out of 10 would do it again."
    new "10 de 10, lo volvería a hacer."

    # game/script.rpy:790
    old "10 out of 10 would {i}not{/i} do it again."
    new "10 de 10, {i}no{/i} lo volvería a hacer."

    # game/script.rpy:813
    old "Yeah, I am."
    new "Sí, lo estoy."

    # game/script.rpy:813
    old "Maybe."
    new "Quizá."

    # game/script.rpy:813
    old "Nah."
    new "Nah."

